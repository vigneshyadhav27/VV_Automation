import pyautogui
import time
import subprocess
import pyperclip

# Step 1: Launch Omnissa Horizon Client
subprocess.Popen(r"C:\Program Files\Omnissa\Omnissa Horizon Client\horizon-client.exe")
time.sleep(5)  # Allow Horizon Client to open

# Step 2: Double-click server tile
pyautogui.click(262, 194, clicks=2)  # Coordinates for server tile
time.sleep(5)

# Step 3: Enter username and password
pyautogui.click(834, 502, clicks=2)  # Username field
pyautogui.hotkey('ctrl', 'a')
pyautogui.press('backspace')
pyperclip.copy("vigneshd")
pyautogui.hotkey("ctrl", "v")
time.sleep(0.5)

pyautogui.press('tab')
pyperclip.copy("Anunta@1234567890@")
pyautogui.hotkey("ctrl", "v")
pyautogui.press('enter')
time.sleep(8)

# Step 4: Select VDI
pyautogui.click(1147, 256, clicks=2)  # Replace with your actual VDI location

time.sleep(25)

# Step 5: Open system tray and select scanner
pyautogui.click(1630, 1046, clicks=1)  # Click system tray icon area

time.sleep(5)
pyautogui.click(1632, 921, clicks=1)  # Click scanner icon (customize if needed)
time.sleep(5)
# Select the Scanner Name (e.g., Brother ADS 2200)

scanner_image = r"C:\Users\Vignesh\Desktop\PY\Scanner\m506_printer.png"
location = pyautogui.locateCenterOnScreen(printer_image, confidence=0.8)

if location:
    pyautogui.click(location)
    print("✅ M506 Printer selected.")
else:
    print("❌ M506 Printer not found.")
    exit()

time.sleep(3)






pyautogui.click(1691, 526, clicks=2)
time.sleep(5)
pyautogui.press('enter')

# Step 6: Open XnView
pyautogui.press('win')
time.sleep(2)
pyautogui.write('xnview', interval=0.1)
pyautogui.press('enter')
time.sleep(5)

# Step 7: Select File -> Select TWAIN Source
pyautogui.click(47, 37, clicks=2)  # Click File menu
time.sleep(5)
pyautogui.click(146, 226, clicks=2)  # Select "Select TWAIN source"
time.sleep(5)

# Step 8: Choose 'Horizon Virtual TWAIN Scanner'
pyautogui.click(280, 258, clicks=2)  # "Horizon Virtual TWAIN Scanner"
time.sleep(2)
pyautogui.press('enter')
time.sleep(2)

# Step 9: Open File menu again
# pyautogui.click(47, 37, clicks=2)  # File menu

# Step 10: Acquire
pyautogui.hotkey('ctrl', 'alt', 'a')
time.sleep(5)

#Step 11: Select Color option
pyautogui.click(655, 220, clicks=2)  # Update with correct coordinates of Color button


# Step 12: Set Resolution to 600 DPI
pyautogui.click(689, 498, clicks=2)  # Update with correct coordinates of resolution box
time.sleep(2)
pyautogui.write("600")
time.sleep(5)
pyautogui.press('enter')
time.sleep(5)

# Step 13: Start Scan
pyautogui.press('enter')
time.sleep(10)
