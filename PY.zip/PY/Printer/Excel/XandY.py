import pyautogui
import time

print("Move your mouse to the desired position...")

while True:
    print(pyautogui.position())
    time.sleep(1)
