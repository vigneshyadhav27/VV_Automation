import pyautogui
import time
import subprocess
import pyperclip
from datetime import datetime

# Track test case results
test_results = []

def log_result(test_case, result):
    status = "PASS" if result else "FAIL"
    test_results.append((test_case, status))

# Step 1: Launch Omnissa Horizon Client
subprocess.Popen(r"C:\Program Files\Omnissa\Omnissa Horizon Client\horizon-client.exe")
time.sleep(5)

# Step 2: Double-click the server tile
pyautogui.click(262, 194, clicks=2)
time.sleep(10)

# Step 3: Click into the username field
pyautogui.click(834, 502, clicks=2)
time.sleep(1)

# Step 4: Clear the prefilled username
pyautogui.hotkey('ctrl', 'a')
time.sleep(0.3)
pyautogui.press('backspace')
time.sleep(0.3)

# Step 5: Paste your username
pyperclip.copy("vigneshd")
pyautogui.hotkey("ctrl", "v")
time.sleep(0.5)

# Step 6: Move to password field
pyautogui.press('tab')
time.sleep(0.5)

# Step 7: Paste your password
pyperclip.copy("Anunta@1234567890@")
pyautogui.hotkey("ctrl", "v")
time.sleep(0.5)

# Step 8: Login
pyautogui.press('enter')
time.sleep(8)

# Step 9: Click the VDI
pyautogui.click(1147, 256, clicks=2)
time.sleep(30)

# Step 10: Open Test.docx
pyautogui.press('win')
time.sleep(3)
pyautogui.write('Testdocument.docx', interval=0.1)
time.sleep(2)
pyautogui.press('enter')
time.sleep(15)

# Step 11: Print the document
pyautogui.hotkey('ctrl', 'p')
time.sleep(8)

# Select Printer
pyautogui.click(901, 287, clicks=2)
time.sleep(1)
printer_image = r"C:\Users\Vignesh\Desktop\PY\Printer\printername_image\m506_printer.png"
location = pyautogui.locateCenterOnScreen(printer_image, confidence=0.8)
log_result("TC1: Select Printer M506", location is not None)
if location:
    pyautogui.click(location)
    print("M506 Printer selected.")
else:
    print("M506 Printer not found.")
    exit()
time.sleep(3)

# TC1.1: Landscape And current page
try:
  
    pyautogui.click(1105, 281, clicks=1) #click the Properties tab
    time.sleep(3)
    pyautogui.click(794, 371, clicks=1) #click the orientation tab
    time.sleep(3)
    pyautogui.press('down') # Press down arrow to select the landscape
    time.sleep(3)
    pyautogui.press('enter') 
    time.sleep(3)
    pyautogui.press('enter')
    time.sleep(3)
    pyautogui.click(693, 577, clicks=1)  # Update this with the correct coordinates current page
    time.sleep(3)
    pyautogui.press('enter')
    log_result("TC1.2: Landscape and current page", True)
except:
    log_result("TC1.2: Landscape and current page", False)
time.sleep(20)

# TC1.2: Portrait with watermark
try:
    pyautogui.hotkey('ctrl', 'p')
    time.sleep(3)
    pyautogui.click(1105, 281, clicks=1) #click the Properties tab
    time.sleep(3)
    pyautogui.click(794, 371, clicks=1) #click the orientation tab
    time.sleep(3)
    pyautogui.press('up') # Press up arrow to select the portrait
    time.sleep(3)
    pyautogui.press('enter') 
    time.sleep(3)
    pyautogui.click(998, 268, clicks=1) #click the watermark tab
    time.sleep(3)
    pyautogui.click(859, 343, clicks=1) #click the watermark text tab
    time.sleep(3)
    pyautogui.press('down') # Press up arrow to select the watermark conent
    time.sleep(3)
    pyautogui.press('enter')
    time.sleep(3)
    pyautogui.press('enter')
    time.sleep(3)
    pyautogui.click(693, 577, clicks=1)  # Update this with the correct coordinates current page
    time.sleep(3)
    pyautogui.press('enter')
    log_result("TC1.2: Portrait with watermark", True)
except:
    log_result("TC1.2: portrait with watermark", False)
time.sleep(20)

# second printer

#  Print the document
pyautogui.hotkey('ctrl', 'p')
time.sleep(5)

# Select Printer
pyautogui.click(901, 287, clicks=2)
time.sleep(3)

printer_image1 = r"C:\Users\Vignesh\Desktop\PY\Printer\printername_image\mf427_printer.png"
location = pyautogui.locateCenterOnScreen(printer_image1, confidence=0.8)
log_result("TC2: Select Printer MFP427", location is not None)
if location:
    pyautogui.click(location)
    print("MFP427 Printer selected.")
else:
    print("MFP427 Printer not found.")
    exit()
time.sleep(3)


# TC2.1: Landscape And current page
try:
  
    pyautogui.click(1105, 281, clicks=1) #click the Properties tab
    time.sleep(3)
    pyautogui.click(794, 371, clicks=1) #click the orientation tab
    time.sleep(3)
    pyautogui.press('down') # Press down arrow to select the landscape
    time.sleep(3)
    pyautogui.press('enter') 
    time.sleep(3)
    pyautogui.press('enter')
    time.sleep(3)
    pyautogui.click(693, 577, clicks=1)  # Update this with the correct coordinates current page
    time.sleep(3)
    pyautogui.press('enter')
    log_result("TC2.1: Landscape and current page", True)
except:
    log_result("TC2.1: Landscape and current page", False)
time.sleep(20)

# TC2.2: Portrait with watermark
try:
    pyautogui.hotkey('ctrl', 'p')
    time.sleep(3)
    pyautogui.click(1105, 281, clicks=1) #click the Properties tab
    time.sleep(3)
    pyautogui.click(794, 371, clicks=1) #click the orientation tab
    time.sleep(3)
    pyautogui.press('up') # Press up arrow to select the portrait
    time.sleep(3)
    pyautogui.press('enter') 
    time.sleep(3)
    pyautogui.click(998, 268, clicks=1) #click the watermark tab
    time.sleep(3)
    pyautogui.click(859, 343, clicks=1) #click the watermark text tab
    time.sleep(3)
    pyautogui.press('down') # Press up arrow to select the watermark conent
    time.sleep(3)
    pyautogui.press('enter')
    time.sleep(3)
    pyautogui.press('enter')
    time.sleep(3)
    pyautogui.click(693, 577, clicks=1)  # Update this with the correct coordinates current page
    time.sleep(3)
    pyautogui.press('enter')
    log_result("TC2.2: Portrait with watermark", True)
except:
    log_result("TC2.2: portrait with watermark", False)
time.sleep(20)

# Final Report
with open("Test_Report.txt", "w") as report:
    report.write("Test Execution Report\n")
    report.write("Generated: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "\n\n")
    for tc, status in test_results:
        report.write(f"{tc}: {status}\n")

print("Test execution complete. Report saved as 'Test_Report.txt'")





