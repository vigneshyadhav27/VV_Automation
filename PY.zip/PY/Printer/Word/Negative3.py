import pyautogui
import time
import pyperclip
import subprocess
from datetime import datetime
import openpyxl
from openpyxl.styles import Font

test_results = []

def log_result(test_case, passed):
    status = "PASS" if passed else "FAIL"
    test_results.append((test_case, status))

# === TC01: Login to Horizon Client ===
try:
    subprocess.Popen(r"C:\Program Files\Omnissa\Omnissa Horizon Client\horizon-client.exe")
    time.sleep(5)
    pyautogui.click(262, 194, clicks=2)
    time.sleep(10)
    pyautogui.click(834, 502, clicks=2)
    pyautogui.hotkey('ctrl', 'a')
    pyautogui.press('backspace')
    pyperclip.copy("vigneshd")
    pyautogui.hotkey("ctrl", "v")
    pyautogui.press('tab')
    pyperclip.copy("Anunta@1234567890@")
    pyautogui.hotkey("ctrl", "v")
    pyautogui.press('enter')
    time.sleep(8)
    pyautogui.click(1147, 256, clicks=2)
    time.sleep(30)
    log_result("TC01 - Login to Horizon Client", True)
except Exception:
    log_result("TC01 - Login to Horizon Client", False)

# === TC1.1: Select M506 Printer and print current page in Landscape ===
try:
    pyautogui.press('win')
    time.sleep(3)
    pyautogui.write('Testdocument.docx', interval=0.1)
    pyautogui.press('enter')
    time.sleep(10)
    pyautogui.hotkey('ctrl', 'p')
    time.sleep(2)
    pyautogui.click(901, 287, clicks=2)
    time.sleep(1)
    printer_image = r"C:\Users\Vignesh\Desktop\PY\Printer\printername_image\m506_printer.png"
    location = pyautogui.locateCenterOnScreen(printer_image, confidence=0.8)
    log_result("TC1.1 - Select Printer M506", location is not None)
    if location:
        pyautogui.click(location)
        time.sleep(2)
        pyautogui.click(1105, 281)  # Properties
        time.sleep(3)
        pyautogui.click(794, 371)  # Orientation
        pyautogui.press('down')
        pyautogui.press('enter')
        pyautogui.press('enter')
        time.sleep(2)
        pyautogui.click(693, 577)  # Current Page
        pyautogui.press('enter')
        log_result("TC1.2 - Landscape + Current Page", True)
    else:
        log_result("TC1.2 - Landscape + Current Page", False)
except Exception:
    log_result("TC1.2 - Landscape + Current Page", False)

# === TC2.1: Select MFP427 Printer but FAIL the print intentionally ===
try:
    pyautogui.click(901, 287, clicks=2)
    time.sleep(2)
    printer_image1 = r"C:\Users\Vignesh\Desktop\PY\Printer\printername_image\mf427_printer.png"
    location = pyautogui.locateCenterOnScreen(printer_image1, confidence=0.8)
    log_result("TC2.1 - Select Printer MFP427", location is not None)
    if location:
        pyautogui.click(location)
        time.sleep(2)
        pyautogui.click(1105, 281)
        time.sleep(2)
        pyautogui.click(794, 371)
        pyautogui.press('down')
        pyautogui.press('enter')
        pyautogui.press('enter')
        time.sleep(2)
        pyautogui.click(693, 577)
        pyautogui.press('enter')
        # Intentionally log this as fail
        log_result("TC2.2 - Landscape Print", False)
    else:
        log_result("TC2.2 - Landscape Print", False)
except Exception:
    log_result("TC2.2 - Landscape Print", False)

# === TC3: Portrait + Watermark ===
try:
    pyautogui.hotkey('ctrl', 'p')
    time.sleep(3)
    pyautogui.click(1105, 281)
    time.sleep(2)
    pyautogui.click(794, 371)
    pyautogui.press('up')
    pyautogui.press('enter')
    pyautogui.click(998, 268)
    pyautogui.click(859, 343)
    pyautogui.press('down')
    pyautogui.press('enter')
    pyautogui.press('enter')
    pyautogui.click(693, 577)
    pyautogui.press('enter')
    log_result("TC3 - Portrait + Watermark", True)
except Exception:
    log_result("TC3 - Portrait + Watermark", False)

# === EXPORT TO EXCEL ===
workbook = openpyxl.Workbook()
sheet = workbook.active
sheet.title = "Test Results"

# Header
sheet["A1"], sheet["B1"] = "Test Case", "Result"
sheet["A1"].font = sheet["B1"].font = Font(bold=True)

# Results
for i, (test, result) in enumerate(test_results, start=2):
    sheet[f"A{i}"] = test
    sheet[f"B{i}"] = result

# Timestamp
timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
sheet[f"A{len(test_results)+3}"] = "Report Generated On:"
sheet[f"B{len(test_results)+3}"] = timestamp

# Save
report_path = f"VDI_Automation_Test_Report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
workbook.save(report_path)
print(f"✅ Test results saved to '{report_path}'")
