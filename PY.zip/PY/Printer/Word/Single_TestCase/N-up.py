import pyautogui
import time
import subprocess
import pyperclip

# Step 1: Launch Omnissa Horizon Client
subprocess.Popen(r"C:\Program Files\Omnissa\Omnissa Horizon Client\horizon-client.exe")
time.sleep(5)

# Step 2: Double-click the server tile
pyautogui.click(262, 194, clicks=2)
time.sleep(5)

# Step 3: Click into the username field
pyautogui.click(834, 502, clicks=2)  # Update these coords if needed
time.sleep(1)

# Step 4: Clear the prefilled username
pyautogui.hotkey('ctrl', 'a')
time.sleep(0.3)
pyautogui.press('backspace')
time.sleep(0.3)

# Step 5: Paste your username
pyperclip.copy("vigneshd")
pyautogui.hotkey("ctrl", "v")
time.sleep(0.5)

# Step 6: Move to password field
pyautogui.press('tab')
time.sleep(0.5)

# Step 7: Paste your password
pyperclip.copy("Anunta@1234567890@")
pyautogui.hotkey("ctrl", "v")
time.sleep(0.5)

# Step 8: Login
pyautogui.press('enter')

# Step 9: Wait for VDI list to load
time.sleep(8)  # Increase if your VDI list takes longer

# Step 10: Click the VDI (update coordinates)
pyautogui.click(1147, 256, clicks=2)  # Replace with your actual VDI location
time.sleep(5)

time.sleep(15)  # wait for VDI desktop to load

# Press Windows key
pyautogui.press('win')
time.sleep(5)

# Type the document name
pyautogui.write('Testdocument.docx', interval=0.1)
time.sleep(5)

# Press Enter to open the document
pyautogui.press('enter')

time.sleep(3)

# Press Ctrl+P to open the print dialog
pyautogui.hotkey('ctrl', 'p')
time.sleep(2)

pyautogui.click(901, 287, clicks=2)  # Update this with the correct coordinates
time.sleep(1)

# Step 3: Type the printer name or scroll to it
pyautogui.write("Hewlett-Packard HP LaserJet MFP M427fdw", interval=0.1)
time.sleep(2)


 #Step 5: Set N-Up layout
# Click on the dropdown for "Pages per Sheet"
pyautogui.click(1128, 743, clicks=2)  # Adjust to correct dropdown location
time.sleep(2)

# Navigate to "2 pages per sheet"
pyautogui.press('down', presses=2, interval=0.5)  # Adjust # of presses as needed
pyautogui.press('enter')
time.sleep(2)

# Optional: Press ENTER to select the printer (if not auto-selected)
pyautogui.press('enter')
time.sleep(2)

# Press Ctrl+P to open the print dialog
pyautogui.hotkey('ctrl', 'p')
time.sleep(2)

# Step 1: Open the printer dropdown before this
pyautogui.click(901, 287, clicks=2)  # Adjust as needed
time.sleep(2)

printer_image = r"C:\Users\Vignesh\Desktop\PY\m506_printer.png"
location = pyautogui.locateCenterOnScreen(printer_image, confidence=0.8)

if location:
    pyautogui.click(location)
    print("✅ M506 Printer selected.")
else:
    print("❌ M506 Printer not found.")
    exit()

time.sleep(3)

# Step 11: Set to current page
pyautogui.click(693, 577)
pyautogui.press('enter')
time.sleep(10)