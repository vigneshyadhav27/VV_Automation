import pyautogui
import time
import subprocess

# === STEP 1: Launch Omnissa Horizon Client ===
subprocess.Popen(r"C:\Program Files\Omnissa\Omnissa Horizon Client\horizon-client.exe")
time.sleep(6)  # Adjust if your app loads slower

# === STEP 2: Double-click the server tile (update coords if needed) ===
pyautogui.click(262, 194, clicks=2)
time.sleep(6)

# === STEP 3: Click into the username field ===
pyautogui.click(834, 502, clicks=2)
time.sleep(1)

# === STEP 4: Clear old username ===
pyautogui.hotkey('ctrl', 'a')
pyautogui.press('backspace')
time.sleep(0.5)

# === STEP 5: Type your username ===
pyautogui.write('vigneshd', interval=0.05)
time.sleep(0.5)

# === STEP 6: Move to password field and enter password ===
pyautogui.press('tab')
time.sleep(0.5)
pyautogui.write('Anunta@1234567890', interval=0.05)
time.sleep(0.5)

# === STEP 7: Submit login ===
pyautogui.press('enter')
time.sleep(8)  # Wait for VDI list to load

# === STEP 8: Find and click VDI using its name image ===
vdi_image_path = 'vdi_name.png'  # Make sure the image is in your script folder

vdi_location = pyautogui.locateCenterOnScreen(vdi_image_path, confidence=0.8)

if vdi_location:
    pyautogui.click(vdi_location)
    print("VDI clicked successfully.")
else:
    print(" VDI image not found. Check screenshot and screen scaling.")
