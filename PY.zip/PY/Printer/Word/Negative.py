import pyautogui
import time
import pyperclip
from docx import Document
from datetime import datetime

# Track test case results
test_results = []

def log_result(test_case, result):
    status = "PASS" if result else "FAIL"
    test_results.append((test_case, status))

# === Test Case 1: Login to Horizon Client ===
try:
    subprocess.Popen(r"C:\Program Files\Omnissa\Omnissa Horizon Client\horizon-client.exe")
    time.sleep(5)
    pyautogui.click(262, 194, clicks=2)
    time.sleep(10)
    pyautogui.click(834, 502, clicks=2)
    time.sleep(1)
    pyautogui.hotkey('ctrl', 'a')
    time.sleep(0.3)
    pyautogui.press('backspace')
    time.sleep(0.3)
    pyperclip.copy("vigneshd")
    pyautogui.hotkey("ctrl", "v")
    time.sleep(0.5)
    pyautogui.press('tab')
    time.sleep(0.5)
    pyperclip.copy("Anunta@1234567890@")
    pyautogui.hotkey("ctrl", "v")
    time.sleep(0.5)
    pyautogui.press('enter')
    time.sleep(8)
    log_result("TC01 - Login to Horizon Client", "PASS")
except Exception as e:
    log_result("TC01 - Login to Horizon Client", "FAIL", str(e))

# === Test Case 2: Select Invalid Printer (Expected to FAIL) ===
try:
    pyautogui.press('win')
    time.sleep(3)
    pyautogui.write('Testdocument.docx', interval=0.1)
    time.sleep(2)
    pyautogui.press('enter')
    time.sleep(15)
    pyautogui.hotkey('ctrl', 'p')
    time.sleep(2)
    pyautogui.click(901, 287, clicks=2)
    time.sleep(2)
    pyautogui.write("Invalid Printer XYZ", interval=0.1)
    time.sleep(2)
    pyautogui.press('enter')
    time.sleep(2)
    log_result("TC02 - Select Invalid Printer", "FAIL", "Printer not found (expected)")
except Exception as e:
    log_result("TC02 - Select Invalid Printer", "PASS (Expected Fail)", str(e))

# === Test Case 3: Open and Print Document ===
try:
    pyautogui.hotkey('ctrl', 'p')
    time.sleep(2)
    pyautogui.press('enter')
    time.sleep(3)
    log_result("TC03 - Print Document", "PASS")
except Exception as e:
    log_result("TC03 - Print Document", "FAIL", str(e))

# === Save Report ===
with open("Test_Report.txt", "w") as report:
    report.write("Test Execution Report\n")
    report.write("Generated: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "\n\n")
    for tc, status in test_results:
        report.write(f"{tc}: {status}\n")

print("Test execution complete. Report saved as 'Test_Report.txt'")

