import pyautogui
import time
import subprocess
import pyperclip

# Step 1: Launch Omnissa Horizon Client
subprocess.Popen(r"C:\Program Files\Omnissa\Omnissa Horizon Client\horizon-client.exe")
time.sleep(5)

# Step 2: Double-click the server tile
pyautogui.click(262, 194, clicks=2)
time.sleep(5)

# Step 3: Click into the username field
pyautogui.click(834, 502, clicks=2)
time.sleep(1)

# Step 4: Clear the prefilled username
pyautogui.hotkey('ctrl', 'a')
time.sleep(0.3)
pyautogui.press('backspace')
time.sleep(0.3)

# Step 5: Paste your username
pyperclip.copy("vigneshd")
pyautogui.hotkey("ctrl", "v")
time.sleep(0.5)

# Step 6: Move to password field
pyautogui.press('tab')
time.sleep(0.5)

# Step 7: Paste your password
pyperclip.copy("Anunta@1234567890#")
pyautogui.hotkey("ctrl", "v")
time.sleep(0.5)

# Step 8: Login
pyautogui.press('enter')

# Step 9: Wait for VDI list to load
time.sleep(8)

# Step 10: Click the VDI
pyautogui.click(1147, 256, clicks=2)
time.sleep(30)

# Step 11: Open PDF
pyautogui.press('win')
time.sleep(3)
pyautogui.write('Testdocument.pdf', interval=0.1)
time.sleep(2)
pyautogui.press('enter')
time.sleep(15)

# Step 12: Print the document
pyautogui.hotkey('ctrl', 'p')
time.sleep(5)

# Step 2: Select Printer
pyautogui.click(651, 221, clicks=2)  # Coordinates for printer drop-down
time.sleep(1)

printer_image1 = r"C:\Users\Vignesh\Desktop\PY\Printer\Excel\printername_image\m506_printer.png"
location = pyautogui.locateCenterOnScreen(printer_image1, confidence=0.8)

if location:
    pyautogui.click(location)
    print("M506 Printer selected.")
else:
    print("M506 Printer not found.")
    exit()

time.sleep(3)

#Step 15 TC:2 N-up
#Step 15.1: Set N-Up layout
#Uncheck the duplex option

pyautogui.click(649, 344, clicks=1)  # All pages
time.sleep(2)
pyautogui.click(662, 503, clicks=1)  # Multiple
time.sleep(2)
pyautogui.click(1458, 851, clicks=1)  # print option


time.sleep(20)
